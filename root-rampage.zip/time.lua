t = 0
never = -1
