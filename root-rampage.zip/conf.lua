function love.conf(t)
    t.window.width = 1280
    t.window.height = 720
    t.version = "11.4"

    t.window.title = "Root Rampage"
    t.window.resizable = true
    t.window.msaa = 0
    t.window.stencil = false
    t.console = true
end
